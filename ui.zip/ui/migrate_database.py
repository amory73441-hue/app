#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Database migration script to add new columns to users table
سكريبت ترحيل قاعدة البيانات لإضافة الأعمدة الجديدة لجدول المستخدمين
"""

import sqlite3
import os
from datetime import datetime

def migrate_users_table():
    """Add new columns to users table"""
    db_path = os.path.join('instance', 'leaves.db')
    
    if not os.path.exists(db_path):
        print("❌ Database file not found at:", db_path)
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check existing columns
        cursor.execute("PRAGMA table_info(users)")
        existing_columns = [row[1] for row in cursor.fetchall()]
        print("📋 Existing columns:", existing_columns)
        
        # Add new columns if they don't exist
        new_columns = [
            ('is_secret', 'INTEGER DEFAULT 0'),
            ('full_name', 'VARCHAR(100)'),
            ('can_create_leaves', 'INTEGER DEFAULT 1'),
            ('can_edit_leaves', 'INTEGER DEFAULT 1')
        ]
        
        for column_name, column_def in new_columns:
            if column_name not in existing_columns:
                alter_sql = f"ALTER TABLE users ADD COLUMN {column_name} {column_def}"
                print(f"🔄 Adding column: {column_name}")
                cursor.execute(alter_sql)
                print(f"✅ Added column: {column_name}")
            else:
                print(f"⚠️ Column {column_name} already exists")
        
        # Update existing users with default values if needed
        cursor.execute("UPDATE users SET is_secret = 0 WHERE is_secret IS NULL")
        cursor.execute("UPDATE users SET can_create_leaves = 1 WHERE can_create_leaves IS NULL")
        cursor.execute("UPDATE users SET can_edit_leaves = 1 WHERE can_edit_leaves IS NULL")
        
        conn.commit()
        print("✅ Database migration completed successfully")
        
        # Show updated table info
        cursor.execute("PRAGMA table_info(users)")
        updated_columns = [row[1] for row in cursor.fetchall()]
        print("📋 Updated columns:", updated_columns)
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error during migration: {e}")
        return False

if __name__ == "__main__":
    print("🚀 Starting database migration...")
    print(f"⏰ Migration started at: {datetime.now()}")
    
    success = migrate_users_table()
    
    if success:
        print("🎉 Migration completed successfully!")
    else:
        print("💥 Migration failed!")
    
    print(f"⏰ Migration finished at: {datetime.now()}")