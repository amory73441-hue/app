#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🛡️ SECURE Flask application starter for UI directory
⚠️ For production: Set environment variables in .env file
🚨 Never run with hardcoded credentials in production!
"""
from dotenv import load_dotenv
load_dotenv()

import os
import sys

# Security check for production environment
flask_env = os.environ.get('FLASK_ENV', 'development')
if flask_env == 'production':
    # In production, all credentials must come from environment
    required_vars = ['SECRET_KEY', 'MAIN_ADMIN_PASSWORD']
    missing_vars = [var for var in required_vars if not os.environ.get(var)]
    if missing_vars:
        print(f'🛑 SECURITY ERROR: Missing required environment variables: {", ".join(missing_vars)}')
        print('🛡️ Set these variables in your production environment')
        sys.exit(1)
else:
    # Development environment - use secure defaults from environment or fallback
    os.environ.setdefault('SECRET_KEY', os.environ.get('SECRET_KEY', 'dev-secret-key-for-replit-test'))
    os.environ.setdefault('CREATE_BACKUP_ADMIN', os.environ.get('CREATE_BACKUP_ADMIN', 'true'))
    
    # For development, use environment variables or prompt user to set them
    if not os.environ.get('MAIN_ADMIN_PASSWORD'):
        print('⚠️  WARNING: MAIN_ADMIN_PASSWORD not set. Please set in .env file')
        print('💡 For development, using temporary password. Change immediately!')
        os.environ.setdefault('MAIN_ADMIN_PASSWORD', 'temp-dev-password-change-me')
    
    if not os.environ.get('BACKUP_ADMIN_PASSWORD'):
        print('⚠️  WARNING: BACKUP_ADMIN_PASSWORD not set. Please set in .env file')
        print('💡 For development, using temporary password. Change immediately!')
        os.environ.setdefault('BACKUP_ADMIN_PASSWORD', 'temp-backup-password-change-me')

# Import and run the Flask app
from app import create_app

if __name__ == '__main__':
    try:
        app = create_app()
        # ⚠️ TEMPORARY DEV FIX: Use 0.0.0.0 for Replit preview access
        host = '0.0.0.0'
        debug_mode = (flask_env == 'development')
        
        print(f"🚀 Starting Flask application on http://{host}:5000/ui")
        
        if flask_env == 'development':
            print("⚠️  WARNING: DEVELOPMENT MODE - NOT FOR PRODUCTION!")
            print("⚠️  TEMPORARY DEV FIX: Binding to 0.0.0.0 for Replit preview access")
            print("🛡️ WARNING: Werkzeug debugger exposed on public interfaces (dev only!)")
            print("📋 Admin usernames: adminakram, ammarad")
            print("🔑 Passwords configured via environment variables")
            print("💡 Access the app at: http://localhost:5000/ui")
            print("🛡️ For production: Set FLASK_ENV=production and configure secure passwords")
        else:
            print("🔒 Production mode - credentials secured via environment variables")
            print("💡 Access the app at: http://localhost:5000/ui")
        app.run(host=host, port=5000, debug=debug_mode, use_reloader=False)
    except Exception as e:
        print(f"❌ Error starting Flask application: {e}")
        import traceback
        traceback.print_exc()
