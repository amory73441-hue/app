#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
نظام إدارة الإجازات المرضية - Flask Application Entry Point
Medical Leave Management System

⚠️ SECURITY WARNING: NEVER run with debug=True in production!
🛡️ For production: Set FLASK_ENV=production and remove debug parameter
"""

from app import create_app
import os

if __name__ == '__main__':
    app = create_app()
    
    # 🚨 CRITICAL SECURITY: Debug mode should NEVER be used in production
    # Debug mode exposes internal application structure and enables remote code execution
    is_development = os.environ.get('FLASK_ENV') == 'development'
    
    if not is_development and app.debug:
        print('🛑 FATAL SECURITY ERROR: Debug mode detected in production!')
        print('🛡️ Set FLASK_ENV=production environment variable')
        raise SystemExit('Debug mode is not allowed in production for security reasons')
    
    # Only enable debug in development
    debug_mode = is_development
    if debug_mode:
        print('⚠️  WARNING: Running in DEBUG mode - for development only!')
        print('🛡️ For production: Set FLASK_ENV=production')
    
    app.run(host='0.0.0.0', port=5000, debug=debug_mode)