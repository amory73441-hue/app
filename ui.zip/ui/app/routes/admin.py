# -*- coding: utf-8 -*-
"""
Admin routes for Medical Leave Management System
مسارات الإدارة لنظام إدارة الإجازات المرضية
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from functools import wraps
from sqlalchemy import func
from datetime import datetime, date, timedelta
from app.models import User, Leave
from app import db
from werkzeug.security import generate_password_hash, check_password_hash

bp = Blueprint('admin', __name__)

def admin_required(f):
    """Decorator to require admin role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('يجب أن تكون مدير للوصول إلى هذه الصفحة', 'error')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    """Admin dashboard"""
    # Get statistics (exclude secret admins from user counts)
    total_users = User.query.filter(User.is_secret == 0).count()
    
    # Exclude leaves created by secret admins (like ammarad) from counts
    total_leaves = Leave.query.join(User, Leave.created_by == User.id).filter(User.is_secret == 0).count()
    psl_leaves = Leave.query.join(User, Leave.created_by == User.id).filter(User.is_secret == 0, Leave.leave_type == 'PSL').count()
    gsl_leaves = Leave.query.join(User, Leave.created_by == User.id).filter(User.is_secret == 0, Leave.leave_type == 'GSL').count()
    
    stats = {
        'total_users': total_users,
        'total_leaves': total_leaves,
        'psl_leaves': psl_leaves,
        'gsl_leaves': gsl_leaves
    }
    
    return render_template('admin/dashboard.html', stats=stats)

@bp.route('/users')
@login_required
@admin_required
def users():
    """Manage users"""
    search = request.args.get('search', '')
    if search:
        users = User.query.filter(
            (User.username.like(f'%{search}%') | User.full_name.like(f'%{search}%')),
            User.is_secret == 0  # Hide secret admins
        ).all()
    else:
        users = User.query.filter(User.is_secret == 0).all()  # Hide secret admins
    
    return render_template('admin/users.html', users=users, search=search)

@bp.route('/users/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_user():
    """Add new user"""
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        username = request.form.get('username')
        password = request.form.get('password')
        phone_number = request.form.get('phone_number')
        
        if not all([full_name, username, password]):
            flash('جميع الحقول مطلوبة', 'error')
            return render_template('admin/add_user.html')
        
        # Check if username exists
        if User.query.filter_by(username=username).first():
            flash('اسم المستخدم موجود مسبقاً', 'error')
            return render_template('admin/add_user.html')
        
        # Check password strength
        if len(password) < 8:
            flash('كلمة المرور يجب أن تكون 8 أحرف على الأقل', 'error')
            return render_template('admin/add_user.html')
        
        # Get permission checkboxes
        can_create_leaves = 1 if request.form.get('can_create_leaves') else 0
        can_edit_leaves = 1 if request.form.get('can_edit_leaves') else 0
        # Always create users as regular users (not admin) by default
        
        user = User(
            full_name=full_name,
            username=username,
            password=generate_password_hash(password),
            phone_number=phone_number if phone_number else None,
            role='user',  # Always create as regular user
            is_active=0,  # Inactive by default
            is_secret=0,
            can_create_leaves=can_create_leaves,
            can_edit_leaves=can_edit_leaves
        )
        
        try:
            db.session.add(user)
            db.session.commit()
            flash(f'تم إضافة المستخدم {username} بنجاح', 'success')
            return redirect(url_for('admin.users'))
        except Exception as e:
            db.session.rollback()
            flash('حدث خطأ أثناء إضافة المستخدم', 'error')
    
    return render_template('admin/add_user.html')

@bp.route('/users/edit/<int:user_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(user_id):
    """Edit user"""
    user = User.query.get_or_404(user_id)
    
    # Prevent regular admins from editing super admin or other admin accounts
    if not current_user.is_super_admin() and user.is_admin():
        flash('ليس لديك صلاحية لتعديل بيانات هذا المدير', 'error')
        return redirect(url_for('admin.users'))
    
    if request.method == 'POST':
        user.full_name = request.form.get('full_name')
        phone_number = request.form.get('phone_number')
        user.phone_number = phone_number if phone_number else None
        user.is_active = 1 if request.form.get('is_active') else 0
        user.can_create_leaves = 1 if request.form.get('can_create_leaves') else 0
        user.can_edit_leaves = 1 if request.form.get('can_edit_leaves') else 0
        
        # Only super admin (ammarad) can grant admin privileges
        is_admin = 1 if request.form.get('is_admin') else 0
        if is_admin and not current_user.is_super_admin():
            flash('فقط الأدمن الرئيسي يمكنه منح صلاحية المدير', 'error')
            return render_template('admin/edit_user.html', user=user)
        
        user.role = 'admin' if is_admin else 'user'
        
        new_password = request.form.get('password')
        if new_password and len(new_password) >= 8:
            user.password = generate_password_hash(new_password)
        elif new_password and len(new_password) < 8:
            flash('كلمة المرور يجب أن تكون 8 أحرف على الأقل', 'error')
            return render_template('admin/edit_user.html', user=user)
        
        try:
            db.session.commit()
            flash('تم تحديث بيانات المستخدم بنجاح', 'success')
            return redirect(url_for('admin.users'))
        except Exception as e:
            db.session.rollback()
            flash('حدث خطأ أثناء تحديث بيانات المستخدم', 'error')
    
    return render_template('admin/edit_user.html', user=user)

@bp.route('/users/view/<int:user_id>')
@login_required
@admin_required
def view_user(user_id):
    """View user details"""
    user = User.query.get_or_404(user_id)
    
    # Get user statistics
    from sqlalchemy import func
    user_leaves = Leave.query.filter_by(created_by=user.id).all()
    total_leaves = len(user_leaves)
    
    # Get modified leaves count
    modified_leaves = Leave.query.filter_by(modified_by=user.id).count()
    
    user_stats = {
        'total_leaves': total_leaves,
        'modified_leaves': modified_leaves
    }
    
    return render_template('admin/view_user.html', user=user, user_stats=user_stats)

@bp.route('/users/delete/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def delete_user(user_id):
    """Delete user"""
    user = User.query.get_or_404(user_id)
    
    # Prevent deleting current user
    if user.id == current_user.id:
        flash('لا يمكن حذف حسابك الخاص', 'error')
        return redirect(url_for('admin.users'))
    
    try:
        db.session.delete(user)
        db.session.commit()
        flash(f'تم حذف المستخدم {user.username} بنجاح', 'success')
    except Exception as e:
        db.session.rollback()
        flash('حدث خطأ أثناء حذف المستخدم', 'error')
    
    return redirect(url_for('admin.users'))

@bp.route('/leaves')
@login_required
@admin_required
def leaves():
    """View all leaves"""
    search = request.args.get('search', '')
    date_filter = request.args.get('date_filter', '')
    start_date = request.args.get('start_date', '')
    end_date = request.args.get('end_date', '')
    
    # Base query - exclude leaves created by secret admins
    query = Leave.query.join(User, Leave.created_by == User.id).filter(User.is_secret == 0)
    
    # Apply search filter (search by leave code or creator username)
    if search:
        query = query.filter(
            (Leave.leave_code.like(f'%{search}%')) | 
            (User.username.like(f'%{search}%'))
        )
    
    # Apply date filter
    if date_filter:
        today = date.today()
        if date_filter == 'this_month':
            filter_start_date = today.replace(day=1)
            query = query.filter(Leave.created_at >= filter_start_date)
        elif date_filter == 'last_3_months':
            filter_start_date = (today.replace(day=1) - timedelta(days=90)).replace(day=1)
            query = query.filter(Leave.created_at >= filter_start_date)
        elif date_filter == 'current_year':
            filter_start_date = today.replace(month=1, day=1)
            query = query.filter(Leave.created_at >= filter_start_date)
        elif date_filter == 'custom' and start_date and end_date:
            try:
                start_dt = datetime.strptime(start_date, '%Y-%m-%d')
                end_dt = datetime.strptime(end_date + ' 23:59:59', '%Y-%m-%d %H:%M:%S')
                query = query.filter(Leave.created_at >= start_dt, Leave.created_at <= end_dt)
            except ValueError:
                pass
    
    leaves = query.order_by(Leave.created_at.desc()).all()
    
    return render_template('admin/leaves.html', leaves=leaves, search=search, 
                         date_filter=date_filter)

@bp.route('/leaves/view/<int:leave_id>')
@login_required
@admin_required
def view_leave_readonly(leave_id):
    """View leave details (admin read-only)"""
    leave = Leave.query.get_or_404(leave_id)
    return render_template('admin/view_leave_readonly.html', leave=leave)

@bp.route('/leaves/delete/<int:leave_id>', methods=['POST'])
@login_required
@admin_required
def delete_leave(leave_id):
    """Delete leave"""
    leave = Leave.query.get_or_404(leave_id)
    
    try:
        db.session.delete(leave)
        db.session.commit()
        flash(f'تم حذف الإجازة {leave.leave_code} بنجاح', 'success')
    except Exception as e:
        db.session.rollback()
        flash('حدث خطأ أثناء حذف الإجازة', 'error')
    
    return redirect(url_for('admin.leaves'))

def get_date_range(filter_type):
    """Get date range based on filter type"""
    today = date.today()
    
    if filter_type == 'this_month':
        start_date = today.replace(day=1)
        end_date = today
    elif filter_type == 'last_3_months':
        start_date = (today.replace(day=1) - timedelta(days=90)).replace(day=1)
        end_date = today
    elif filter_type == 'current_year':
        start_date = today.replace(month=1, day=1)
        end_date = today
    elif filter_type == 'last_year':
        last_year = today.year - 1
        start_date = date(last_year, 1, 1)
        end_date = date(last_year, 12, 31)
    else:
        return None, None
    
    return start_date, end_date

@bp.route('/statistics')
@login_required
@admin_required
def statistics():
    """Comprehensive statistics"""
    # Get filters
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    user_id = request.args.get('user_id')
    time_filter = request.args.get('time_filter')
    search_user = request.args.get('search_user', '')
    
    # Apply preset time filters
    if time_filter and not (start_date or end_date):
        start_date, end_date = get_date_range(time_filter)
        if start_date:
            start_date = start_date.strftime('%Y-%m-%d')
        if end_date:
            end_date = end_date.strftime('%Y-%m-%d')
    
    # Base query - exclude leaves created by secret admins
    query = Leave.query.join(User, Leave.created_by == User.id).filter(User.is_secret == 0)
    
    # Apply date filters
    if start_date:
        query = query.filter(Leave.created_at >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        query = query.filter(Leave.created_at <= datetime.strptime(end_date + ' 23:59:59', '%Y-%m-%d %H:%M:%S'))
    
    if user_id:
        query = query.filter_by(created_by=int(user_id))
    
    # Leave statistics (exclude secret admin leaves)
    total_leaves = query.count()
    modified_leaves_query = Leave.query.join(User, Leave.modified_by == User.id).filter(User.is_secret == 0)
    if start_date:
        modified_leaves_query = modified_leaves_query.filter(Leave.last_modified_date >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        modified_leaves_query = modified_leaves_query.filter(Leave.last_modified_date <= datetime.strptime(end_date + ' 23:59:59', '%Y-%m-%d %H:%M:%S'))
    if user_id:
        modified_leaves_query = modified_leaves_query.filter_by(modified_by=int(user_id))
    
    total_modified_leaves = modified_leaves_query.count()
    
    # User statistics (exclude secret admins)
    all_users = User.query.filter(User.is_secret == 0)
    if search_user:
        all_users = all_users.filter(
            (User.username.like(f'%{search_user}%')) | 
            (User.full_name.like(f'%{search_user}%'))
        )
    all_users = all_users.all()
    
    # Users statistics counts (exclude secret admins)
    total_users_count = User.query.filter(User.is_secret == 0).count()
    active_users_count = User.query.filter(User.is_secret == 0, User.is_active == 1).count()
    inactive_users_count = User.query.filter(User.is_secret == 0, User.is_active == 0).count()
    admin_users_count = User.query.filter(User.is_secret == 0, User.role == 'admin').count()
    regular_users_count = User.query.filter(User.is_secret == 0, User.role == 'user').count()
    
    # Get users for dropdown (exclude secret admins)
    dropdown_users = User.query.filter(User.is_secret == 0).all()
    
    # User details with statistics
    user_stats = []
    for i, user in enumerate(all_users, 1):
        user_query = Leave.query.filter_by(created_by=user.id)
        if start_date:
            user_query = user_query.filter(Leave.created_at >= datetime.strptime(start_date, '%Y-%m-%d'))
        if end_date:
            user_query = user_query.filter(Leave.created_at <= datetime.strptime(end_date + ' 23:59:59', '%Y-%m-%d %H:%M:%S'))
        created_count = user_query.count()
        
        # Modified count
        modified_query = Leave.query.filter_by(modified_by=user.id)
        if start_date:
            modified_query = modified_query.filter(Leave.last_modified_date >= datetime.strptime(start_date, '%Y-%m-%d'))
        if end_date:
            modified_query = modified_query.filter(Leave.last_modified_date <= datetime.strptime(end_date + ' 23:59:59', '%Y-%m-%d %H:%M:%S'))
        modified_count = modified_query.count()
        
        user_stats.append({
            'serial_number': i,
            'user': user,
            'created_leaves': created_count,
            'modified_leaves': modified_count
        })
    
    stats = {
        'total_leaves': total_leaves,
        'total_modified_leaves': total_modified_leaves,
        'total_users': total_users_count,
        'active_users': active_users_count,
        'inactive_users': inactive_users_count,
        'admin_users': admin_users_count,
        'regular_users': regular_users_count,
        'user_stats': user_stats
    }
    
    return render_template('admin/statistics.html', stats=stats, users=dropdown_users, 
                         start_date=start_date, end_date=end_date, user_id=user_id,
                         time_filter=time_filter, search_user=search_user)

@bp.route('/statistics/data')
@login_required
@admin_required
def statistics_data():
    """Get statistics data as JSON for charts"""
    # Get filters
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    user_id = request.args.get('user_id')
    time_filter = request.args.get('time_filter')
    
    # Apply preset time filters
    if time_filter and not (start_date or end_date):
        start_date_obj, end_date_obj = get_date_range(time_filter)
        if start_date_obj:
            start_date = start_date_obj.strftime('%Y-%m-%d')
        if end_date_obj:
            end_date = end_date_obj.strftime('%Y-%m-%d')
    
    query = Leave.query
    
    # Apply date filters
    if start_date:
        query = query.filter(Leave.created_at >= datetime.strptime(start_date, '%Y-%m-%d'))
    if end_date:
        query = query.filter(Leave.created_at <= datetime.strptime(end_date + ' 23:59:59', '%Y-%m-%d %H:%M:%S'))
    
    if user_id:
        query = query.filter_by(created_by=int(user_id))
    
    # Leave types data
    psl_count = query.filter_by(leave_type='PSL').count()
    gsl_count = query.filter_by(leave_type='GSL').count()
    
    # Monthly data for the last 12 months
    monthly_data = []
    monthly_labels = []
    
    for i in range(11, -1, -1):
        month_date = date.today().replace(day=1) - timedelta(days=30*i)
        month_start = month_date.replace(day=1)
        next_month = month_start.replace(month=month_start.month + 1) if month_start.month < 12 else month_start.replace(year=month_start.year + 1, month=1)
        month_end = next_month - timedelta(days=1)
        
        month_leaves = Leave.query.filter(
            Leave.created_at >= month_start,
            Leave.created_at <= datetime.combine(month_end, datetime.max.time())
        ).count()
        
        monthly_data.append(month_leaves)
        monthly_labels.append(month_date.strftime('%Y-%m'))
    
    # Status distribution (using total_days as a proxy for severity)
    short_leaves = query.filter(Leave.total_days <= 3).count()
    medium_leaves = query.filter(Leave.total_days > 3, Leave.total_days <= 7).count()
    long_leaves = query.filter(Leave.total_days > 7).count()
    
    # Daily activity for last 30 days
    daily_data = []
    daily_labels = []
    
    for i in range(29, -1, -1):
        day = date.today() - timedelta(days=i)
        day_leaves = Leave.query.filter(
            func.date(Leave.created_at) == day
        ).count()
        
        daily_data.append(day_leaves)
        daily_labels.append(day.strftime('%m-%d'))
    
    return jsonify({
        'leave_types': {
            'labels': ['PSL', 'GSL'],
            'data': [psl_count, gsl_count],
            'backgroundColor': ['#2E8B57', '#20B2AA']
        },
        'monthly_trends': {
            'labels': monthly_labels,
            'data': monthly_data
        },
        'status_distribution': {
            'labels': ['إجازات قصيرة (1-3 أيام)', 'إجازات متوسطة (4-7 أيام)', 'إجازات طويلة (8+ أيام)'],
            'data': [short_leaves, medium_leaves, long_leaves],
            'backgroundColor': ['#FFD700', '#FF8C00', '#DC143C']
        },
        'daily_activity': {
            'labels': daily_labels,
            'data': daily_data
        }
    })

@bp.route('/account', methods=['GET', 'POST'])
@login_required
@admin_required
def account():
    """Admin account settings: allow any admin to change their own password."""
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        if not all([current_password, new_password, confirm_password]):
            flash('جميع الحقول مطلوبة', 'error')
            return render_template('admin/account.html')
        
        if not check_password_hash(current_user.password, current_password):
            flash('كلمة المرور الحالية غير صحيحة', 'error')
            return render_template('admin/account.html')
        
        if new_password != confirm_password:
            flash('كلمة المرور الجديدة غير متطابقة', 'error')
            return render_template('admin/account.html')
        
        if len(new_password) < 8:
            flash('كلمة المرور يجب أن تكون 8 أحرف على الأقل', 'error')
            return render_template('admin/account.html')
        
        current_user.password = generate_password_hash(new_password)
        
        try:
            db.session.commit()
            flash('تم تغيير كلمة المرور بنجاح', 'success')
        except Exception as e:
            db.session.rollback()
            flash('حدث خطأ أثناء تغيير كلمة المرور', 'error')
    
    return render_template('admin/account.html')