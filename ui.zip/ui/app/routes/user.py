# -*- coding: utf-8 -*-
"""
User routes for Medical Leave Management System
مسارات المستخدم لنظام إدارة الإجازات المرضية
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from functools import wraps
from sqlalchemy import func, text
from datetime import datetime, date, timedelta
import re
from app.models import User, Leave
from app import db

bp = Blueprint('user', __name__)

def validate_national_id(national_id):
    """Validate national ID/residence number (5-13 digits)"""
    if not national_id:
        return False, "رقم الهوية / الإقامة مطلوب"
    
    # Check if only digits and length between 5-13
    if not re.match(r'^\d{5,13}$', national_id.strip()):
        return False, "رقم الهوية / الإقامة يجب أن يحتوي على 5-13 رقم فقط"
    
    return True, None

def user_required(f):
    """Decorator to require user role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@bp.route('/dashboard')
@login_required
@user_required
def dashboard():
    """User dashboard"""
    return render_template('user/dashboard.html')

@bp.route('/leaves')
@login_required
@user_required
def leaves():
    """View user's leaves with filtering and statistics"""
    search = request.args.get('search', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    # Base query for user's leaves  
    query = Leave.query.filter_by(created_by=current_user.id)
    base_query = Leave.query.filter_by(created_by=current_user.id)  # For unfiltered counts
    
    # Apply search filter
    if search:
        # Search in leave code, full name, and national ID
        query = query.filter(
            text("leave_code LIKE :search OR full_name LIKE :search OR national_id LIKE :search")
        ).params(search=f'%{search}%')
    
    # Apply date range filter
    if date_from:
        try:
            from_date = datetime.strptime(date_from, '%Y-%m-%d').date()
            query = query.filter(Leave.start_date >= from_date)
        except ValueError:
            pass
    
    if date_to:
        try:
            to_date = datetime.strptime(date_to, '%Y-%m-%d').date()
            query = query.filter(Leave.end_date <= to_date)
        except ValueError:
            pass
    
    # Get filtered leaves
    leaves = query.order_by(Leave.created_at.desc()).all()
    
    # Calculate statistics based on filters
    filtered_total_leaves = len(leaves)
    
    # Calculate modified leaves count (filtered)
    modified_leaves_query = Leave.query.filter_by(modified_by=current_user.id, created_by=current_user.id)
    if search:
        modified_leaves_query = modified_leaves_query.filter(
            text("leave_code LIKE :search OR full_name LIKE :search OR national_id LIKE :search")
        ).params(search=f'%{search}%')
    if date_from:
        try:
            from_date = datetime.strptime(date_from, '%Y-%m-%d').date()
            modified_leaves_query = modified_leaves_query.filter(Leave.start_date >= from_date)
        except ValueError:
            pass
    if date_to:
        try:
            to_date = datetime.strptime(date_to, '%Y-%m-%d').date()
            modified_leaves_query = modified_leaves_query.filter(Leave.end_date <= to_date)
        except ValueError:
            pass
    
    filtered_modified_leaves = modified_leaves_query.count()
    
    # For default display (no filters applied), show total counts
    if not search and not date_from and not date_to:
        total_leaves_count = base_query.count()
        total_modified_count = Leave.query.filter_by(modified_by=current_user.id, created_by=current_user.id).count()
    else:
        total_leaves_count = filtered_total_leaves
        total_modified_count = filtered_modified_leaves
    
    summary = {
        'total_leaves': total_leaves_count,
        'modified_leaves': total_modified_count,
        'filtered_total': filtered_total_leaves,
        'filtered_modified': filtered_modified_leaves
    }
    
    return render_template('user/leaves.html', 
                         leaves=leaves, 
                         search=search, 
                         date_from=date_from,
                         date_to=date_to,
                         summary=summary)

@bp.route('/leaves/add', methods=['GET', 'POST'])
@login_required
@user_required
def add_leave():
    """Add new leave"""
    # Check if user has permission to create leaves
    if not current_user.can_create_leave():
        flash('ليس لديك صلاحية لإنشاء الإجازات', 'error')
        return redirect(url_for('user.leaves'))
    
    if request.method == 'POST':
        try:
            # Get form data
            leave_type = request.form.get('leave_type')
            national_id = request.form.get('national_id')
            full_name = request.form.get('full_name')
            doctor_name = request.form.get('doctor_name')
            job_title = request.form.get('job_title')
            start_date = request.form.get('start_date')
            end_date = request.form.get('end_date')
            issue_date = request.form.get('issue_date')
            
            # Validation
            if not all([leave_type, national_id, full_name, doctor_name, job_title, start_date, end_date]):
                flash('جميع الحقول مطلوبة', 'error')
                return render_template('user/add_leave.html')
            
            # Validate national ID
            is_valid, error_msg = validate_national_id(national_id)
            if not is_valid:
                flash(error_msg, 'error')
                return render_template('user/add_leave.html')
            
            # Convert dates
            if not start_date:
                flash('تاريخ البداية مطلوب', 'error')
                return render_template('user/add_leave.html')
            if not end_date:
                flash('تاريخ النهاية مطلوب', 'error')
                return render_template('user/add_leave.html')
            
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
            issue_date = datetime.strptime(issue_date, '%Y-%m-%d').date() if issue_date else date.today()
            
            # Create leave
            leave = Leave(
                leave_type=leave_type,
                national_id=national_id,
                full_name=full_name,
                doctor_name=doctor_name,
                job_title=job_title,
                start_date=start_date,
                end_date=end_date,
                issue_date=issue_date,
                created_by=current_user.id
            )
            
            # Validate dates only (overlap check removed)
            leave.validate_dates()
            # leave.check_overlap(current_user.id)  # Removed overlap check
            
            db.session.add(leave)
            db.session.commit()
            
            flash(f'تم إضافة الإجازة بنجاح - رمز الإجازة: {leave.leave_code}', 'success')
            return redirect(url_for('user.view_leave', leave_id=leave.id))
            
        except ValueError as e:
            flash(str(e), 'error')
            return render_template('user/add_leave.html')
        except Exception as e:
            db.session.rollback()
            flash('حدث خطأ أثناء إضافة الإجازة', 'error')
            return render_template('user/add_leave.html')
    
    return render_template('user/add_leave.html')

@bp.route('/leaves/edit/<int:leave_id>', methods=['GET', 'POST'])
@login_required
@user_required
def edit_leave(leave_id):
    """Edit leave"""
    leave = Leave.query.get_or_404(leave_id)
    
    # Only creator can edit
    if leave.created_by != current_user.id:
        flash('لا يمكنك تعديل هذه الإجازة', 'error')
        return redirect(url_for('user.leaves'))
    
    # Check if user has permission to edit leaves
    if not current_user.can_edit_leave():
        flash('ليس لديك صلاحية لتعديل الإجازات', 'error')
        return redirect(url_for('user.leaves'))
    
    if request.method == 'POST':
        try:
            # Get and validate national ID
            national_id = request.form.get('national_id')
            is_valid, error_msg = validate_national_id(national_id)
            if not is_valid:
                flash(error_msg, 'error')
                return render_template('user/edit_leave.html', leave=leave)
            
            # Update leave data (except leave_code)
            leave.national_id = national_id
            leave.full_name = request.form.get('full_name')
            leave.doctor_name = request.form.get('doctor_name')
            leave.job_title = request.form.get('job_title')
            start_date_str = request.form.get('start_date')
            end_date_str = request.form.get('end_date')
            issue_date_str = request.form.get('issue_date')
            
            if not start_date_str:
                flash('تاريخ البداية مطلوب', 'error')
                return render_template('user/edit_leave.html', leave=leave)
            if not end_date_str:
                flash('تاريخ النهاية مطلوب', 'error')
                return render_template('user/edit_leave.html', leave=leave)
            if not issue_date_str:
                flash('تاريخ الإصدار مطلوب', 'error')
                return render_template('user/edit_leave.html', leave=leave)
            
            leave.start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            leave.end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
            leave.issue_date = datetime.strptime(issue_date_str, '%Y-%m-%d').date()
            
            # Update audit fields
            leave.modified_by = current_user.id
            leave.last_modified_date = datetime.utcnow()
            
            # Recalculate total days and validate
            leave.calculate_total_days()
            leave.validate_dates()
            # leave.check_overlap()  # Removed overlap check
            
            db.session.commit()
            flash('تم تحديث الإجازة بنجاح', 'success')
            return redirect(url_for('user.view_leave', leave_id=leave.id))
            
        except ValueError as e:
            flash(str(e), 'error')
        except Exception as e:
            db.session.rollback()
            flash('حدث خطأ أثناء تحديث الإجازة', 'error')
    
    return render_template('user/edit_leave.html', leave=leave)

@bp.route('/leaves/view/<int:leave_id>')
@login_required
@user_required
def view_leave(leave_id):
    """View leave details"""
    leave = Leave.query.get_or_404(leave_id)
    
    # Only creator can view
    if leave.created_by != current_user.id:
        flash('لا يمكنك عرض هذه الإجازة', 'error')
        return redirect(url_for('user.leaves'))
    
    return render_template('user/view_leave.html', leave=leave)

@bp.route('/leaves/delete/<int:leave_id>', methods=['POST'])
@login_required
@user_required
def delete_leave(leave_id):
    """Delete leave (disabled for normal users)."""
    flash('الحذف غير مسموح للمستخدمين العاديين. يرجى التواصل مع الإدارة.', 'error')
    return redirect(url_for('user.leaves'))

def get_personal_date_range(period):
    """Get date range for personal statistics based on period"""
    today = date.today()
    
    if period == 'this_year':
        start_date = today.replace(month=1, day=1)
        end_date = today
    elif period == 'last_6_months':
        start_date = (today.replace(day=1) - timedelta(days=180)).replace(day=1)
        end_date = today
    elif period == 'last_3_months':
        start_date = (today.replace(day=1) - timedelta(days=90)).replace(day=1)
        end_date = today
    else:  # 'all'
        return None, None
    
    return start_date, end_date

@bp.route('/statistics')
@login_required
@user_required
def statistics():
    """User personal statistics page"""
    return render_template('user/statistics.html')

@bp.route('/statistics/data')
@login_required
@user_required
def statistics_data():
    """Get personal statistics data as JSON"""
    # Get period filter
    period = request.args.get('period', 'all')
    
    # Get date range
    start_date, end_date = get_personal_date_range(period)
    
    # Base query for user's leaves
    query = Leave.query.filter_by(created_by=current_user.id)
    
    # Apply date filters if specified
    if start_date:
        query = query.filter(Leave.created_at >= start_date)
    if end_date:
        query = query.filter(Leave.created_at <= datetime.combine(end_date, datetime.max.time()))
    
    # Basic statistics
    total_leaves = query.count()
    total_days = db.session.query(func.sum(Leave.total_days)).filter(
        Leave.created_by == current_user.id
    ).scalar() or 0
    
    if start_date:
        period_total_days = db.session.query(func.sum(Leave.total_days)).filter(
            Leave.created_by == current_user.id,
            Leave.created_at >= start_date,
            Leave.created_at <= (datetime.combine(end_date, datetime.max.time()) if end_date else datetime.now())
        ).scalar() or 0
    else:
        period_total_days = total_days
    
    avg_duration = (period_total_days / total_leaves) if total_leaves > 0 else 0
    
    # This year leaves
    current_year_start = date.today().replace(month=1, day=1)
    this_year_leaves = Leave.query.filter(
        Leave.created_by == current_user.id,
        Leave.created_at >= current_year_start
    ).count()
    
    # Leave types data for chart
    psl_count = query.filter_by(leave_type='PSL').count()
    gsl_count = query.filter_by(leave_type='GSL').count()
    
    # Monthly trends for the last 12 months
    monthly_data = []
    monthly_labels = []
    
    for i in range(11, -1, -1):
        month_date = date.today().replace(day=1) - timedelta(days=30*i)
        month_start = month_date.replace(day=1)
        next_month = month_start.replace(month=month_start.month + 1) if month_start.month < 12 else month_start.replace(year=month_start.year + 1, month=1)
        month_end = next_month - timedelta(days=1)
        
        month_leaves = Leave.query.filter(
            Leave.created_by == current_user.id,
            Leave.created_at >= month_start,
            Leave.created_at <= datetime.combine(month_end, datetime.max.time())
        ).count()
        
        monthly_data.append(month_leaves)
        monthly_labels.append(month_date.strftime('%Y-%m'))
    
    # Leave history for timeline
    recent_leaves = Leave.query.filter_by(created_by=current_user.id).order_by(Leave.created_at.desc()).limit(10).all()
    leave_history = []
    
    for leave in recent_leaves:
        leave_history.append({
            'leave_code': leave.leave_code,
            'leave_type': leave.leave_type,
            'total_days': leave.total_days,
            'start_date': leave.start_date.strftime('%Y-%m-%d') if leave.start_date else '',
            'end_date': leave.end_date.strftime('%Y-%m-%d') if leave.end_date else '',
            'created_at': leave.created_at.strftime('%Y-%m-%d') if leave.created_at else '',
            'full_name': leave.full_name
        })
    
    # Performance summary
    total_user_leaves = Leave.query.filter_by(created_by=current_user.id).count()
    total_user_days = db.session.query(func.sum(Leave.total_days)).filter(
        Leave.created_by == current_user.id
    ).scalar() or 0
    
    avg_user_days = (total_user_days / total_user_leaves) if total_user_leaves > 0 else 0
    
    performance_note = ""
    if total_user_leaves == 0:
        performance_note = "لم تقم بإنشاء أي إجازات حتى الآن"
    elif avg_user_days <= 3:
        performance_note = "معظم إجازاتك قصيرة المدى - هذا جيد لصحتك العامة"
    elif avg_user_days <= 7:
        performance_note = "إجازاتك متوسطة المدى - حافظ على صحتك"
    else:
        performance_note = "إجازاتك طويلة المدى - تأكد من متابعة حالتك الصحية"
    
    # Recommendations
    recommendations = []
    if total_user_leaves == 0:
        recommendations.append("ابدأ بتسجيل إجازاتك المرضية في النظام")
    else:
        if psl_count > gsl_count:
            recommendations.append("معظم إجازاتك من نوع PSL - راجع مع طبيبك للوقاية")
        if avg_user_days > 5:
            recommendations.append("متوسط إجازاتك طويل - تأكد من الراحة الكافية")
        if this_year_leaves > 6:
            recommendations.append("عدد إجازاتك هذا العام مرتفع - اهتم بصحتك الوقائية")
        
        if len(recommendations) == 0:
            recommendations.append("تبدو إجازاتك ضمن المعدل الطبيعي - أحسنت!")
    
    return jsonify({
        'stats': {
            'total_leaves': total_leaves,
            'total_days': int(period_total_days),
            'avg_duration': round(avg_duration, 1),
            'this_year_leaves': this_year_leaves
        },
        'charts': {
            'leave_types': {
                'labels': ['PSL', 'GSL'],
                'data': [psl_count, gsl_count],
                'backgroundColor': ['#2E8B57', '#20B2AA']
            },
            'trends': {
                'labels': monthly_labels,
                'datasets': [{
                    'label': 'إجازاتي الشهرية',
                    'data': monthly_data,
                    'borderColor': '#2E8B57',
                    'backgroundColor': 'rgba(46, 139, 87, 0.1)',
                    'borderWidth': 3,
                    'tension': 0.4,
                    'fill': True
                }]
            }
        },
        'history': leave_history,
        'summary': {
            'performance': {
                'total_leaves': total_user_leaves,
                'avg_days': round(avg_user_days, 1),
                'note': performance_note
            },
            'recommendations': recommendations
        }
    })
