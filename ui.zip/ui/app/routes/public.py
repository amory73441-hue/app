# -*- coding: utf-8 -*-
"""
Public routes for Medical Leave Management System - Inquiry Page
المسارات العامة لنظام إدارة الإجازات المرضية - صفحة الاستعلامات
"""

from flask import Blueprint, render_template, request, jsonify, redirect, url_for
from app.models import Leave

bp = Blueprint('public', __name__)

@bp.route('/inquiry', methods=['GET', 'POST'])
@bp.route('/inquiries/slenquiry/', methods=['GET', 'POST'])
def inquiry():
    """Public inquiry page - exact match for the specified design"""
    if request.method == 'POST':
        service_code = request.form.get('service_code', '').strip()
        national_id = request.form.get('national_id', '').strip()
        
        if not service_code or not national_id:
            return render_template('public/inquiry.html', 
                                 error='يرجى إدخال رقم الخدمة ورقم الهوية / الإقامة')
        
        # Search for leave
        leave = Leave.query.filter_by(leave_code=service_code, national_id=national_id).first()
        
        if leave:
            return render_template('public/inquiry.html', 
                                 leave=leave, 
                                 service_code=service_code,
                                 national_id=national_id)
        else:
            return render_template('public/inquiry.html',
                                 error='لم يتم العثور على الإجازة المطلوبة',
                                 service_code=service_code,
                                 national_id=national_id)
    
    return render_template('public/inquiry.html')

@bp.route('/api/inquiry', methods=['POST'])
def api_inquiry():
    """API endpoint for inquiry (for AJAX requests)"""
    data = request.get_json()
    service_code = data.get('service_code', '').strip()
    national_id = data.get('national_id', '').strip()
    
    if not service_code or not national_id:
        return jsonify({'error': 'يرجى إدخال رقم الخدمة ورقم الهوية / الإقامة'}), 400
    
    leave = Leave.query.filter_by(leave_code=service_code, national_id=national_id).first()
    
    if leave:
        return jsonify({
            'success': True,
            'leave': leave.to_dict()
        })
    else:
        return jsonify({'error': 'لم يتم العثور على الإجازة المطلوبة'}), 404