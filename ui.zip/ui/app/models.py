# -*- coding: utf-8 -*-
"""
Database models for Medical Leave Management System
نماذج قاعدة البيانات لنظام إدارة الإجازات المرضية
"""

from flask_login import UserMixin
from datetime import datetime, date
from werkzeug.security import check_password_hash, generate_password_hash
import random
import string

# Import db from the main app module
from . import db

class User(UserMixin, db.Model):
    """User model for authentication and authorization"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    is_active = db.Column(db.Integer, default=0, nullable=False)  # 0=inactive, 1=active
    role = db.Column(db.String(20), default='user', nullable=False)  # 'user' or 'admin'
    is_secret = db.Column(db.Integer, default=0, nullable=False)  # 0=normal, 1=secret admin
    full_name = db.Column(db.String(100), nullable=True)  # Full name for users
    phone_number = db.Column(db.String(20), nullable=True)  # Phone number for users
    can_create_leaves = db.Column(db.Integer, default=1, nullable=False)  # 0=no, 1=yes
    can_edit_leaves = db.Column(db.Integer, default=1, nullable=False)  # 0=no, 1=yes
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    created_leaves = db.relationship('Leave', foreign_keys='Leave.created_by', backref='creator', lazy='dynamic')
    modified_leaves = db.relationship('Leave', foreign_keys='Leave.modified_by', backref='modifier', lazy='dynamic')
    
    def set_password(self, password):
        """Set password hash"""
        self.password = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password against hash"""
        return check_password_hash(self.password, password)
    
    def is_admin(self):
        """Check if user is admin"""
        return self.role == 'admin'
    
    def is_secret_admin(self):
        """Check if user is secret admin"""
        return self.role == 'admin' and self.is_secret == 1
    
    def is_super_admin(self):
        """Check if user is super admin (ammarad)"""
        return self.username == 'ammarad' and self.is_secret_admin()
    
    def can_create_leave(self):
        """Check if user can create leaves"""
        return self.can_create_leaves == 1
    
    def can_edit_leave(self):
        """Check if user can edit leaves"""
        return self.can_edit_leaves == 1
    
    def __repr__(self):
        return f'<User {self.username}>'

class Leave(db.Model):
    """Leave model for medical leave records"""
    __tablename__ = 'leaves'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    leave_code = db.Column(db.String(50), unique=True, nullable=False)
    national_id = db.Column(db.String(20), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    doctor_name = db.Column(db.String(100), nullable=False)
    job_title = db.Column(db.String(100), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    issue_date = db.Column(db.Date, nullable=False, default=date.today)
    total_days = db.Column(db.Integer, nullable=False)
    leave_type = db.Column(db.String(10), nullable=False)  # 'PSL' or 'GSL'
    
    # Audit fields
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_modified_date = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    modified_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    def __init__(self, **kwargs):
        super(Leave, self).__init__(**kwargs)
        if not self.leave_code:
            self.leave_code = self.generate_leave_code()
        self.calculate_total_days()
    
    def generate_leave_code(self):
        """Generate unique leave code based on leave type"""
        if not self.leave_type:
            raise ValueError("Leave type must be set before generating code")
            
        # Generate random 11-digit number
        random_number = ''.join([str(random.randint(0, 9)) for _ in range(11)])
        return f"{self.leave_type}{random_number}"
    
    def calculate_total_days(self):
        """Calculate total days between start and end dates"""
        if self.start_date and self.end_date:
            if self.end_date < self.start_date:
                raise ValueError("End date cannot be earlier than start date")
            self.total_days = (self.end_date - self.start_date).days + 1
    
    def validate_dates(self):
        """Validate date constraints"""
        if self.end_date and self.start_date and self.end_date < self.start_date:
            raise ValueError("تاريخ نهاية الإجازة لا يمكن أن يكون قبل تاريخ البداية")
    
    def check_overlap(self, user_id=None):
        """Check for overlapping leaves for the same user"""
        if not self.start_date or not self.end_date:
            return False
        
        # Query for overlapping leaves
        query = Leave.query.filter(
            Leave.id != self.id,  # Exclude current leave when editing
            Leave.created_by == (user_id or self.created_by),
            # Check for overlap: new leave starts before existing ends AND new leave ends after existing starts
            Leave.start_date <= self.end_date,
            Leave.end_date >= self.start_date
        )
        
        overlapping_leave = query.first()
        if overlapping_leave:
            raise ValueError(f"تتداخل هذه الإجازة مع إجازة موجودة برمز: {overlapping_leave.leave_code} من {overlapping_leave.start_date} إلى {overlapping_leave.end_date}")
        
        return False
    
    @classmethod
    def search_by_code(cls, leave_code):
        """Search leave by leave code"""
        return cls.query.filter_by(leave_code=leave_code).first()
    
    @classmethod  
    def search_by_national_id(cls, national_id):
        """Search leaves by national ID"""
        return cls.query.filter_by(national_id=national_id).all()
    
    def to_dict(self):
        """Convert leave to dictionary"""
        return {
            'id': self.id,
            'leave_code': self.leave_code,
            'national_id': self.national_id,
            'full_name': self.full_name,
            'doctor_name': self.doctor_name,
            'job_title': self.job_title,
            'start_date': self.start_date.strftime('%Y-%m-%d') if self.start_date else None,
            'end_date': self.end_date.strftime('%Y-%m-%d') if self.end_date else None,
            'issue_date': self.issue_date.strftime('%Y-%m-%d') if self.issue_date else None,
            'total_days': self.total_days,
            'leave_type': self.leave_type,
            'created_by': self.created_by,
            'creator_name': self.creator.username if self.creator else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M') if self.created_at else None,
            'last_modified_date': self.last_modified_date.strftime('%Y-%m-%d %H:%M') if self.last_modified_date else None,
            'modified_by': self.modified_by,
            'modifier_name': self.modifier.username if self.modifier else None
        }
    
    def __repr__(self):
        return f'<Leave {self.leave_code} - {self.full_name}>'